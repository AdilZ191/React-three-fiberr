import { LayerProvider } from "contexts/layerSelector";
import React, { Component } from "react";
import { PinsContext, PinsProvider } from "./contexts/pinContext";
import Home from "./Pages/Home";

class App extends Component {
  render() {
    return (
      <div className="App">
        <PinsProvider>
          <LayerProvider>
            <Home />
          </LayerProvider>
        </PinsProvider>
      </div>
    );
  }
}
export default App;
