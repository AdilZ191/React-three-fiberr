import React, { Component } from "react";
import "../../App.css";
import Layer1 from "../../Components/Layer1";
import Layer2 from "../../Components/Layer2";
import Layer3 from "../../Components/Layer3";
import Layer4 from "../../Components/Layer4";
import Layer1Pins from "../../Components/Layer1/Pins";
import Layer2Pins from "../../Components/Layer2/Pins";
import Layer3Pins from "../../Components/Layer3/Pins";
import Layer4Pins from "../../Components/Layer4/Pins";
import Aside from "../../Components/Aside";
import SvgIcons from "../../Components/SvgIcons";
import { PinsContext } from "../../contexts/pinContext";
import BottomData from "../../Components/BottomData/BottomData";
import FilterBox from "./FilterBox/FilterBox";

class Home extends Component {
  constructor(props) {
    super(props);
    this.levelMenu = React.createRef();
    this.levelOne = React.createRef();

    this.state = {
      selectedLevel: -1,
      showContextMenu: false,
      levelOnePins: [],
      pin: {},
      isSearchOpen: false,
    };
  }
  static contextType = PinsContext;

  componentDidMount() {
    document.addEventListener("click", (e) => {
      const clickedOutside = !(e.target.contains === this.levelMenu);

      if (clickedOutside && this.state.showContextMenu) {
        this.setState({ showContextMenu: false });
      }
    });
  }

  handleLevelClick = (level, e) => {
    if (this.state.selectedLevel === level) {
      console.log("e.nativeEvent.offsetX", e?.nativeEvent?.offsetX);
    } else {
      this.setState({ selectedLevel: level, isSearchOpen: false });
    }
  };

  handleNextPrevLevelClick(level) {
    if (level >= 1 && level <= 4) {
      this.setState({ selectedLevel: level });
    }
  }

  handleShowAllLevelsClick() {
    this.setState({ selectedLevel: -1 });
  }

  handleLevelContextMenu(e) {
    e.preventDefault();
    this.setState({ showContextMenu: true });

    const clickX = e.clientX;
    const clickY = e.clientY;
    const screenW = window.innerWidth;
    const screenH = window.innerHeight;
    const rootW = this.levelMenu.current.offsetWidth;
    const rootH = this.levelMenu.current.offsetHeight;

    const right = screenW - clickX > rootW;
    const left = !right;
    const top = screenH - clickY > rootH;
    const bottom = !top;

    if (right) {
      this.levelMenu.current.style.left = `${clickX}px`;
    }

    if (left) {
      this.levelMenu.current.style.left = `${clickX - rootW}px`;
    }

    if (top) {
      this.levelMenu.current.style.top = `${clickY}px`;
    }

    if (bottom) {
      this.levelMenu.current.style.top = `${clickY - rootH}px`;
    }

    this.setState({
      pin: {
        style: {
          left: this.calculateVmin(e.clientX),
          top: this.calculateVmin(e.clientY),
        },
      },
    });
  }

  handleAddPinClick() {
    var pins = this.state.levelOnePins;
    pins.push(this.state.pin);
    this.setState({ levelOnePins: pins });
  }

  calculateVmin(px) {
    let percentage = 0;
    percentage = (100 / window.innerWidth) * px;

    return `${percentage}vh`;
  }

  openContent = (data) => {
    console.log("data", data);
  };

  handleSearchClick = () => {
    this.setState({
      isSearchOpen: !this.state.isSearchOpen,
      selectedLevel: -1,
    });
  };

  render() {
    return (
      <div>
        <SvgIcons />
        <div className="container">
          <div className="main">
            <div className="mall" ref={(e) => (this.mall = e)}>
              <div
                className={
                  "levels " +
                  (this.state.selectedLevel > 0
                    ? `levels--open levels--selected-${this.state.selectedLevel}`
                    : "")
                }
              >
                <div
                  ref={this.levelOne}
                  onContextMenu={this.handleLevelContextMenu.bind(this)}
                  className={
                    "level level--1 " +
                    (this.state.selectedLevel === 1 ? "level--current" : "")
                  }
                  aria-label="Level 1"
                  onClick={this.handleLevelClick.bind(this, 1)}
                >
                  <Layer1 />
                  <div
                    className={
                      "level__pins " +
                      (this.state.selectedLevel === 1
                        ? "level__pins--active"
                        : "")
                    }
                  >
                    <Layer1Pins />
                  </div>
                </div>
                <div
                  className={
                    "level level--2 " +
                    (this.state.selectedLevel === 2 ? "level--current" : "")
                  }
                  aria-label="Level 2"
                  onClick={this.handleLevelClick.bind(this, 2)}
                >
                  <Layer2 />
                  <div
                    className={
                      "level__pins " +
                      (this.state.selectedLevel === 2
                        ? "level__pins--active"
                        : "")
                    }
                  >
                    <Layer2Pins openContent={this.openContent} />
                  </div>
                </div>
                <div
                  className={
                    "level level--3 " +
                    (this.state.selectedLevel === 3 ? "level--current" : "")
                  }
                  aria-label="Level 3"
                  onClick={this.handleLevelClick.bind(this, 3)}
                >
                  <Layer3 />
                  <div
                    className={
                      "level__pins " +
                      (this.state.selectedLevel === 3
                        ? "level__pins--active"
                        : "")
                    }
                  >
                    <Layer3Pins />
                  </div>
                </div>
                <div
                  className={
                    "level level--4 " +
                    (this.state.selectedLevel === 4 ? "level--current" : "")
                  }
                  aria-label="Level 4"
                  onClick={this.handleLevelClick.bind(this, 4)}
                >
                  <Layer4 />
                  <div
                    className={
                      "level__pins " +
                      (this.state.selectedLevel === 4
                        ? "level__pins--active"
                        : "")
                    }
                  >
                    <Layer4Pins />
                  </div>
                </div>
              </div>
            </div>
            <button
              onClick={this.handleSearchClick}
              className="boxbutton boxbutton--dark open-search"
              aria-label="Show search"
            >
              <svg className="icon icon--search">
                <use xlinkHref="#icon-search"></use>
              </svg>
            </button>
            <nav
              className={
                "mallnav " +
                (this.state.selectedLevel > 0 ? "" : "mallnav--hidden")
              }
            >
              <button
                className={
                  "boxbutton mallnav__button--up " +
                  (this.state.selectedLevel === 4 ? "boxbutton--disabled" : "")
                }
                onClick={this.handleNextPrevLevelClick.bind(
                  this,
                  this.state.selectedLevel + 1
                )}
                aria-label="Go up"
                disabled={this.state.selectedLevel === 4}
              >
                <svg className="icon icon--angle-down">
                  <use xlinkHref="#icon-angle-up"></use>
                </svg>
              </button>
              <button
                className="boxbutton boxbutton--dark mallnav__button--all-levels"
                onClick={this.handleShowAllLevelsClick.bind(this)}
                aria-label="Back to all levels"
              >
                <svg className="icon icon--stack">
                  <use xlinkHref="#icon-stack"></use>
                </svg>
              </button>
              <button
                className={
                  "boxbutton mallnav__button--down " +
                  (this.state.selectedLevel === 1 ? "boxbutton--disabled" : "")
                }
                onClick={this.handleNextPrevLevelClick.bind(
                  this,
                  this.state.selectedLevel - 1
                )}
                aria-label="Go down"
                disabled={this.state.selectedLevel === 1}
              >
                <svg className="icon icon--angle-down">
                  <use xlinkHref="#icon-angle-down"></use>
                </svg>
              </button>
            </nav>
          </div>
          <Aside />
        </div>
        <BottomData data={this.context?.data} reset={this.context?.reset} />
        {this.state.isSearchOpen && (
          <FilterBox
            handleSearchClick={this.handleSearchClick}
            handleLevelClick={this.handleLevelClick}
          />
        )}
      </div>
    );
  }
}

export default Home;
