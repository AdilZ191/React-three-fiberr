import { useContext, useState } from "react";
import "./filter-box.css";
import layer1Pins from "Components/Layer1/Pins/pins.json";
import layer2Pins from "Components/Layer2/Pins/pins.json";
import layer3Pins from "Components/Layer3/Pins/pins.json";
import layer4Pins from "Components/Layer4/Pins/pins.json";
import { PinsContext } from "contexts/pinContext";

function FilterBox({ handleSearchClick, handleLevelClick }) {
  const [currentValue, setCurrentValue] = useState("");
  const { data, handleChange } = useContext(PinsContext);

  const handleChangePin = (layer, pin) => {
    handleLevelClick(layer);
    handleChange(pin);
  };

  const handleChangeValue = (e) => {
    const { value } = e.target;
    setCurrentValue(value);
  };

  return (
    <div className="filter-content">
      <div className="search-box">
        <input
          type="text"
          placeholder="Search..."
          value={currentValue}
          onChange={handleChangeValue}
        />
      </div>

      <div className="list-content">
        {layer1Pins.filter((each) =>
          each?.info?.title?.toLowerCase().includes(currentValue.toLowerCase())
        ).length !== 0 && <h4>Layer 1</h4>}

        {layer1Pins
          .filter((each) =>
            each?.info?.title
              ?.toLowerCase()
              .includes(currentValue.toLowerCase())
          )
          .map((each) => (
            <p onClick={() => handleChangePin(1, each)}>{each?.info?.title}</p>
          ))}
      </div>

      <div className="list-content">
        {layer2Pins.filter((each) =>
          each?.info?.title?.toLowerCase().includes(currentValue.toLowerCase())
        ).length !== 0 && <h4>Layer 2</h4>}

        {layer2Pins
          .filter((each) =>
            each?.info?.title
              ?.toLowerCase()
              .includes(currentValue.toLowerCase())
          )
          .map((each) => (
            <p onClick={() => handleChangePin(2, each)}>{each?.info?.title}</p>
          ))}
      </div>

      <div className="list-content">
        {layer3Pins.filter((each) =>
          each?.info?.title?.toLowerCase().includes(currentValue.toLowerCase())
        ).length !== 0 && <h4>Layer 3</h4>}

        {layer3Pins
          .filter((each) =>
            each?.info?.title
              ?.toLowerCase()
              .includes(currentValue.toLowerCase())
          )
          .map((each) => (
            <p onClick={() => handleChangePin(3, each)}>{each?.info?.title}</p>
          ))}
      </div>

      <div className="list-content">
        {layer4Pins.filter((each) =>
          each?.info?.title?.toLowerCase().includes(currentValue.toLowerCase())
        ).length !== 0 && <h4>Layer 4</h4>}

        {layer4Pins
          .filter((each) =>
            each?.info?.title
              ?.toLowerCase()
              .includes(currentValue.toLowerCase())
          )
          .map((each) => (
            <p onClick={() => handleChangePin(4, each)}>{each?.info?.title}</p>
          ))}
      </div>

      <button
        onClick={handleSearchClick}
        className="boxbutton boxbutton--dark open-search"
        aria-label="Show search"
      >
        <svg className="icon icon--cross">
          <use xlinkHref="#icon-cross"></use>
        </svg>
      </button>
    </div>
  );
}

export default FilterBox;
