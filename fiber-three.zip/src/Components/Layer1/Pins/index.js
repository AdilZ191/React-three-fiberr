import { useContext } from "react";
import pinsData from "./pins.json";
import { PinsContext } from "../../../contexts/pinContext";

const Layer1Pins = () => {
  const { handleChange } = useContext(PinsContext);

  const handleChangePin = (data) => {
    handleChange(data);
  };

  return (
    <>
      {pinsData.map((each, idx) => (
        <a
          key={each.pin}
          className={`pin pin--1-${idx + 1}`}
          data-category={each.category}
          data-space={`1.0${idx + 1}`}
          onClick={() => handleChangePin(each)}
          style={{
            top: `${each.style.top}vmin`,
            left: `${each.style.left}vmin`,
          }}
          aria-label={each.info.label}
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className={`icon icon--logo icon--${each.info.icon}`}>
              <use xlinkHref={`#icon-${each.info.icon}`}></use>
            </svg>
          </span>
        </a>
      ))}
    </>
  );
};

export default Layer1Pins;
