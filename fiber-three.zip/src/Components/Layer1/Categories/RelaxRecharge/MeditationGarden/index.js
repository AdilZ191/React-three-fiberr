import React from 'react';

const MeditationGarden = () => {
    return <h1>MeditationGarden</h1>;
}

export default MeditationGarden;