import React from 'react';

const FoldingLife = () => {
    return <h1>FoldingLife</h1>;
}

export default FoldingLife;

