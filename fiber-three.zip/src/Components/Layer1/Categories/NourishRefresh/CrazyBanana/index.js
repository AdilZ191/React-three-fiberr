import React from 'react';

const CrazyBanana = () => {
    return <h1>CrazyBanana</h1>;
}

export default CrazyBanana;