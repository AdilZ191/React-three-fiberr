import React from 'react';

const SmoothiesSoul = () => {
    return <h1>SmoothiesSoul</h1>;
}

export default SmoothiesSoul;