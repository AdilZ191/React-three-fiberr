import React from 'react';

const AppleHeart = () => {
    return <h1>AppleHeart</h1>;
}

export default AppleHeart;