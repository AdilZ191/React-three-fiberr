import React from 'react';

const SeedofLife = () => {
    return <h1>SeedofLife</h1>;
}

export default SeedofLife;