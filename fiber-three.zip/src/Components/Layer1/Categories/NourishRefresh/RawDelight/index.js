import React from 'react';

const RawDelight = () => {
    return <h1>RawDelight</h1>;
}

export default RawDelight;