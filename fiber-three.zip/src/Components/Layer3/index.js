import * as THREE from "three";
import React, {
  Suspense,
  useState,
  useRef,
  useEffect,
  useLayoutEffect,
  useMemo,
} from "react";
import { Canvas, useLoader } from "@react-three/fiber";
import { SVGLoader } from "three/examples/jsm/loaders/SVGLoader";
import { MapControls } from "@react-three/drei";

function Cell({ color, shape, fillOpacity, text }) {
  const [hovered, set] = useState(false);
  return (
    <mesh onPointerOver={(e) => set(true)} onPointerOut={() => set(false)}>
      <meshBasicMaterial
        color={hovered ? "#f0f0f0" : "#BCBCBC"}
        opacity={fillOpacity}
        depthWrite={false}
        transparent
      />
      <shapeBufferGeometry args={[shape]} />
    </mesh>
  );
}

function Svg({ url }) {
  const { paths } = useLoader(SVGLoader, url);
  const shapes = useMemo(
    () =>
      paths.flatMap((p) =>
        p.toShapes(true).map((shape) => ({ shape, color: p.color }))
      ),
    [paths]
  );

  const ref = useRef();
  useLayoutEffect(() => {
    const sphere = new THREE.Box3()
      .setFromObject(ref.current)
      .getBoundingSphere(new THREE.Sphere());
    ref.current.position.set(-sphere.center.x, -sphere.center.y, 0);
  }, []);

  return (
    <group ref={ref}>
      {shapes.map((props, index) => (
        <Cell key={props.shape.uuid} {...props} />
      ))}
    </group>
  );
}

const Layer3 = () => {
  return (
    <Canvas
      style={{ height: "100vh", width: "100vw" }}
      frameloop="demand"
      orthographic
      camera={{ position: [0, 0, 50], zoom: 2, up: [0, 0, 1], far: 10000 }}
    >
      <Suspense fallback={null}>
        <Svg url="svg/layer3.svg" />
      </Suspense>
      <MapControls enableRotate={false} />
    </Canvas>
  );
};

export default Layer3;
