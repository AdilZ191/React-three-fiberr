import "./bottomStyles.css";

function BottomData({ data, reset }) {
  return (
    <div className={`pin-data${data.isOpen ? " active" : " inactive"}`}>
      <div className="data-container">
        <h3 className={`pin-title color-${data?.color}`}>{data.info?.title}</h3>
        <p>
          <span>
            <b>Opening Hours: </b>
            {data?.info?.openingHours}
          </span>{" "}
          <span>
            <b>Phone: </b>
            {data?.info?.phone}
          </span>
        </p>

        <p>{data?.info?.description}</p>
      </div>

      <div className="close-button" onClick={reset}>
        X
      </div>
    </div>
  );
}

export default BottomData;
