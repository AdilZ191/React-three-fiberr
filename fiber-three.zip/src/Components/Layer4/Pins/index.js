import React, { useContext } from "react";
import { PinsContext } from "../../../contexts/pinContext";
import pinsData from "./pins.json";

const Layer4Pins = () => {
  const { handleChange } = useContext(PinsContext);

  const handleChangePin = (data) => {
    handleChange(data);
  };

  return (
    <>
      {pinsData.map((each, idx) => (
        <a
          key={each.pin}
          className={`pin pin--4-${idx + 1}`}
          data-category={each.category}
          data-space={`4.0${idx + 1}`}
          style={{
            top: `${each.style.top}vmin`,
            left: `${each.style.left}vmin`,
          }}
          onClick={() => handleChangePin(each)}
          aria-label={each.info.label}
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className={`icon icon--logo icon--${each.info.icon}`}>
              <use xlinkHref={`#icon-${each.info.icon}`}></use>
            </svg>
          </span>
        </a>
      ))}
    </>
  );
};

export default Layer4Pins;
