import { useContext } from "react";
import pinsData from "./pins.json";
import { PinsContext } from "../../../contexts/pinContext";

const Layer2Pins = () => {
  const { handleChange } = useContext(PinsContext);

  const handleChangePin = (data) => {
    handleChange(data);
  };

  return (
    <>
      {pinsData.map((each, idx) => (
        <a
          key={each.pin}
          className={`pin pin--2-${idx + 1}`}
          data-category={each.category}
          data-space={`2.0${idx + 1}`}
          onClick={() => handleChangePin(each)}
          aria-label={each.info.label}
          style={{
            top: `${each.style.top}vmin`,
            bottom: `${each.style.top}vmin`,
            left: `${each.style.left}vmin`,
            right: `${each.style.left}vmin`,
          }}
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className={`icon icon--logo icon--${each.info.icon}`}>
              <use xlinkHref={`#icon-${each.info.icon}`}></use>
            </svg>
          </span>
        </a>
      ))}

      {/* <a
          className="pin pin--2-1"
          data-category="1"
          data-space="2.01"
          href="#"
          aria-label="Pin for Grilled Chipotle"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--pepper">
              <use xlinkHref="#icon-pepper"></use>
            </svg>
          </span>
        </a>
        <a
          className="pin pin--2-2"
          data-category="2"
          data-space="2.02"
          href="#"
          aria-label="Pin for Rocketship Tech"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--rocket">
              <use xlinkHref="#icon-rocket"></use>
            </svg>
          </span>
        </a>
        <a
          className="pin pin--2-3"
          data-category="2"
          data-space="2.03"
          href="#"
          aria-label="Pin for Which Bug?"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--bug">
              <use xlinkHref="#icon-bug"></use>
            </svg>
          </span>
        </a>
        <a
          className="pin pin--2-4"
          data-category="3"
          data-space="2.04"
          href="#"
          aria-label="Pin for Cognitio"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--books">
              <use xlinkHref="#icon-books"></use>
            </svg>
          </span>
        </a>
        <a
          className="pin pin--2-5"
          data-category="1"
          data-space="2.05"
          href="#"
          aria-label="Pin for The Eggplanthead"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--eggplant">
              <use xlinkHref="#icon-eggplant"></use>
            </svg>
          </span>
        </a>
        <a
          className="pin pin--2-6"
          data-category="1"
          data-space="2.06"
          href="#"
          aria-label="Pin for Superfood"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--strawberry">
              <use xlinkHref="#icon-strawberry"></use>
            </svg>
          </span>
        </a>
        <a
          className="pin pin--2-7"
          data-category="3"
          data-space="2.07"
          href="#"
          aria-label="Pin for No Princess"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--heart">
              <use xlinkHref="#icon-heart"></use>
            </svg>
          </span>
        </a>
        <a
          className="pin pin--2-8"
          data-category="3"
          data-space="2.08"
          href="#"
          aria-label="Pin for Tool Exchange"
        >
          <span className="pin__icon">
            <svg className="icon icon--pin">
              <use xlinkHref="#icon-pin"></use>
            </svg>
            <svg className="icon icon--logo icon--wrench">
              <use xlinkHref="#icon-wrench"></use>
            </svg>
          </span>
        </a> */}
    </>
  );
};

export default Layer2Pins;
