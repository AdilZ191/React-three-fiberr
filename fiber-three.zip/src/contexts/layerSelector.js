import { createContext, useState } from "react";

export const LayerContext = createContext();

export const LayerProvider = (props) => {
  const [currentLayer, setLayer] = useState(-1);

  const handleChange = (newData) => {
    setLayer(newData);
  };

  const reset = () => {
    setLayer(-1);
  };

  return (
    <LayerContext.Provider value={{ currentLayer, handleChange, reset }}>
      {props.children}
    </LayerContext.Provider>
  );
};
