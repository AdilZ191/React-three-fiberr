import { createContext, useState } from "react";

export const PinsContext = createContext();

export const PinsProvider = (props) => {
  const [data, setData] = useState({ pin: 0, info: {}, isOpen: false });

  const handleChange = (newData) => {
    setData(newData);
  };

  const reset = () => {
    setData({ pin: 0, info: {}, isOpen: false });
  };

  return (
    <PinsContext.Provider value={{ data, handleChange, reset }}>
      {props.children}
    </PinsContext.Provider>
  );
};
